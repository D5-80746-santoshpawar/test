#include "../include/person.h"
#include "../include/product.h"
#include "../include/seller.h"

int main(){
    Person person;                      //object of class Person
    Seller seller;                      //object of class seller
    person.menue();                            //calling funtion menue
    return 0;
}