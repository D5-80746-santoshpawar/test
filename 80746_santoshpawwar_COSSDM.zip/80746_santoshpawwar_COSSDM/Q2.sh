ls -i /home
ls -i ~

