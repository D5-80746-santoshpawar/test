result=$(echo "5.2 + 3.8" | bc)
echo "The result is: $result"

